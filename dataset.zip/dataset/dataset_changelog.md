# Dataset changelog

## 25/09/2024

- Dataset empezado
- 26 animaciones "dance"
- 6 animaciones "greeting"
- 24 animaciones "fight"
- 3 animaciones "run"

## 28/09/2024

- 96 animaciones "dance"
- 6 animaciones "greeting"
- 96 animaciones "fight"
- 11 animaciones "point out"
- 96 animaciones "run"
- 96 animaciones "sit"
