# Dataset changelog

## 25/09/2024

- Dataset empezado
- 26 animaciones "dance"
- 6 animaciones "greeting"
